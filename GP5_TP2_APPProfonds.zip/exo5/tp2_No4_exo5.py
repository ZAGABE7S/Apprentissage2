import pandas as pd
import tensorflow as tf
import keras as k
import matplotlib.pyplot as plt
from keras.models import Sequential
from keras.layers import Dense
from keras.utils import to_categorical
from sklearn.metrics import confusion_matrix

dataset = pd.read_csv('letter_trn.csv', delimiter = ";")
dataset_test = pd.read_csv('letter_tst.csv', delimiter = ";")
x = dataset.iloc[:,1:17]
y = dataset.iloc[:,-1]

x_test = dataset_test.iloc[:,1:17]
y_test = dataset_test.iloc[:,-1]

encode_y = to_categorical(y)
encode_ytest = to_categorical(y_test)

model = Sequential()
model.add(Dense(units = 6, kernel_initializer = 'uniform' , activation = 'relu' , input_dim = 16))
model.add(Dense(units = 6, kernel_initializer = 'uniform' , activation = 'relu'))
model.add(Dense(units = 6, kernel_initializer = 'uniform' , activation = 'relu'))
model.add(Dense(units = 26, kernel_initializer = 'uniform' , activation = 'softmax'))

model.compile(optimizer = 'adam', loss = 'binary_crossentropy', metrics = ['accuracy'])
model.fit(x, encode_y, batch_size = 10, epochs = 20)

y_predict = model.predict(x_test)
y_predict = (y_predict >= 0.4)
print(y_predict)

con_m = confusion_matrix(encode_ytest.argmax(axis=1), y_predict.argmax(axis=1))
print(con_m)
