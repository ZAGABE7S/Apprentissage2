import numpy as np
import matplotlib.pyplot as pl
import tensorflow as tf
from numpy import genfromtxt

data = genfromtxt("leuk.csv",delimiter=";").astype("float32")
np.maximum(data[:,-1],0,data[:,-1])

X = data[:,:-1]
y = data[:,-1].astype("int")

data_X = tf.placeholder(tf.float32,shape=[None,X.shape[1]])
data_y = tf.placeholder(tf.float32, [None])

w1 = tf.Variable(tf.random_normal([X.shape[1], 1]))
b1 = tf.Variable(tf.zeros([1]))
pred = tf.nn.sigmoid(tf.matmul(data_X, w1) + b1)

loss = tf.reduce_mean(tf.square(pred - data_y))
correct_prediction = tf.equal(tf.round(pred), data_y)
accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
optimizer = tf.train.GradientDescentOptimizer(learning_rate=0.1)
train = optimizer.minimize(loss)

init = tf.global_variables_initializer()
with tf.Session() as sess:
    sess.run(init)
    for e in range(1000):
        _, c = sess.run([train, loss], feed_dict={data_X: X,data_y: y})
        print("Epoch", e, " Loss: ", c, "  Accuracy: ", sess.run(accuracy, feed_dict={data_X: X,data_y: y}))       