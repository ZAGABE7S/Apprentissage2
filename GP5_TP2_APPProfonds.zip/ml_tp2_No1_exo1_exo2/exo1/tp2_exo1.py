from __future__ import absolute_import, division, print_function

import tensorflow as tf
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

w = tf.Variable(tf.zeros((2, 1))) #w: initialisée par 0
b = tf.Variable(-0.5, tf.float32) #b: -0.5
x = tf.placeholder(tf.float32, (4, 2)) # entrée
predict = tf.nn.sigmoid(tf.matmul(x, w) + b) # la sortie (prediction)

y = tf.placeholder(tf.float32, (4, 1)) #sortie souhaitée
loss = tf.reduce_sum(tf.square(y - predict), 0) #fonction de perte
train_step = tf.train.GradientDescentOptimizer(0.2).minimize(loss) #optimiseur
loss=[]

data_x = np.array([[0, 0],
[0, 1],
[1, 0],
[1, 1]]) #donnée d'apprentissage: x
data_y = np.array([[0.0], [1.0], [1.0], [1.0]]) #donnée d'apprentissage: y
nb_it = 1000 #nombre d’itérations
sess = tf.Session()
sess.run(tf.global_variables_initializer()) #init des variables
sess.run(w.assign([[0.4], [0.5]])) #initialiser w = [0.4, 0.5]
for i in range(0, nb_it):
    sess.run(train_step, {x: data_x, y: data_y}) #entrainer le perceptron
p = sess.run(predict, {x: data_x}) #prédire sur l’ensemble d’apprentissage
w_value = sess.run(w) #prendre les valeurs de w et
b_value = sess.run(b)
print("Les sorties: ", p)
print("Les classes: ", (p>0.5).astype(int))
print("Weight: ", w_value)
print("Biais: ", b_value)

#Visualisation 
array1 = [0, 0, 1, 1]
array2 = [0, 1, 0, 1]
data_y = [0, 1, 1, 1]
x1 = np.arange(0, 1, 0.01)
x2 = (-1*b_value - w_value[0][0]*x1)/w_value[1][0]
y1 = -1*x1+1
y2 = -1*x1
y3 = x1
plt.plot(x1, y2, 'g')
plt.plot(x1, y1, 'g')
plt.plot(x1, y3, 'r')
color = ['red' if y == 0 else 'green' for y in data_y]
plt.scatter(array1, array2, color=color)
plt.show()