import tensorflow as tf
import numpy as np
import keras
from keras.preprocessing import sequence
from keras.models import Sequential
from keras.models import Model
from keras.optimizers import Adam
from keras.utils import to_categorical

model = tf.keras.Sequential([
tf.keras.layers.Dense(3, activation='softmax', input_shape=(2,), use_bias=True)])

model.compile(optimizer='adam',
loss='sparse_categorical_crossentropy',
metrics=['accuracy'])

data_x = np.array([[0, 0],
                   [0, 1],
                   [1, 0],
                   [1, 1],
                   [0, 0],
                   [0, 1],
                   [1, 0],
                   [1, 1]]) #donnée d'apprentissage: x
data_y = np.array([[0], [1], 
                   [2], [1],
                   [0], [1], 
                   [1], [1]]) #donnée d'apprentissage:y

model.fit(data_x, data_y, epochs=100)

predict = tf.keras.layers.Dense(3, activation='softmax', input_shape=(2,),
use_bias=True)
model = tf.keras.Sequential([
predict
])
print(predict.get_weights())