import tensorflow as tf
import numpy as np
import keras
from keras.preprocessing import sequence
from keras.models import Sequential
from keras.models import Model

model = tf.keras.Sequential([
tf.keras.layers.Dense(1, activation='sigmoid', input_shape=(2,), use_bias=True)])

model.compile(optimizer='adam',
loss='binary_crossentropy',
metrics=['accuracy'])

data_x = np.array([[0, 0],
[0, 1],
[1, 0],
[1, 1]]) #donnée d'apprentissage: x
data_y = np.array([[1], [1], [1], [1]]) #donnée d'apprentissage:

model.fit(data_x, data_y, epochs=5)

predict = tf.keras.layers.Dense(1, activation='sigmoid', input_shape=(2,),
use_bias=True)
model = tf.keras.Sequential([
predict
])

print(predict.get_weights())