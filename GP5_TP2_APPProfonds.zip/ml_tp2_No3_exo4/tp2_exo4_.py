import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt

def forward(x, w1, b1, w2, b2, train=True):
    h =tf.nn.relu(tf.matmul(x, w1) + b1) # couche cachee
    predict = tf.matmul(h, w2) + b2 # la sortie (prediction
    if train:
        return predict
    return tf.nn.sigmoid(predict)

X = np.array([
    [0.204000, 0.834000], [0.222000, 0.730000], 
    [0.298000, 0.822000], [0.450000, 0.842000], 
    [0.412000, 0.732000], [0.298000, 0.640000], 
    [0.588000, 0.298000], [0.554000, 0.398000], 
    [0.670000, 0.466000], [0.834000, 0.426000], 
    [0.724000, 0.368000], [0.790000, 0.262000], 
    [0.824000, 0.338000], [0.136000, 0.260000], 
    [0.146000, 0.374000], [0.258000, 0.422000],
    [0.292000, 0.282000], [0.478000, 0.568000], 
    [0.654000, 0.776000], [0.786000, 0.758000],
    [0.690000, 0.628000], [0.736000, 0.786000],
    [0.574000, 0.742000]
    ])
y = np.array([[0], [0], [0], [0],
    [0], [0], [0], [0],[0], [0], [0], [0],
    [0], [1], [1], [1],[1], [1], [1], [1],
    [1], [1], [1]])

data_X = tf.placeholder(tf.float32, [None, 2])
data_Y = tf.placeholder(tf.float32, [None, 1] )

w1 = tf.Variable(tf.random_uniform((2, 2), -1, 1)) #w: initialisée par 0
b1 = tf.Variable(tf.zeros((2,)), tf.float32)
w2 = tf.Variable(tf.random_uniform((2, 1), -1, 1)) #w: initialisée par 0
b2 = tf.Variable(0.0, tf.float32)


y_hat = forward(data_X, w1, b1, w2, b2)
pred = forward(data_X, w1, b1, w2, b2, False)

lr = 0.1

epochs = 1000
display_steps = 200

cost = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=y_hat, labels = data_Y))

train = tf.train.AdamOptimizer(lr).minimize(cost)

costs = []

init = tf.global_variables_initializer()
with tf.Session() as sess:
    sess.run(init)

    for epoch in range(epochs):
        sess.run(train, feed_dict={data_X: X, data_Y: y})
        c = sess.run(cost, feed_dict = {data_X: X, data_Y: y})
        costs.append(c)

        if (epoch + 1) % display_steps == 0:
            print(f"Iteration {epoch + 1}. Cost: {c}.")
   
    train_result = sess.run(y_hat, feed_dict={data_X: X})
    correct_pred = tf.equal(tf.argmax(train_result, 1), tf.argmax(y, 1))

    accuracy = tf.reduce_mean(tf.cast(correct_pred, "float"))
    print ("Accuracy:", accuracy.eval({data_X: X, data_Y: y}))       
    print("Training complete.")

    prediction = sess.run(pred, feed_dict={data_X: X})
    print("Pourcentage: ")
    print(prediction)
    print("Prediction: ")
    print(np.round(prediction))

    plt.plot(costs)
    plt.show()
